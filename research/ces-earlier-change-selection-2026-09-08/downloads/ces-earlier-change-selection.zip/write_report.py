"""从验收结果生成中文报告与可筛选表格，不手抄计数。"""
import argparse
import csv
import io
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
G={'all':'全体','Latino_employed_2020':'2020拉美裔在业','R_renter_2020':'2020共和党倾向租房'}
C={'full':'完整两波','retained':'后来留存','omitted':'后来未留存'}
M={'house':'众院票','pid':'党派认同'}

def fmt(x,d=3): return '不可计算' if x is None else f'{x:+.{d}f}'

def csv_bytes(rows):
    s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    return s.getvalue().encode('utf-8-sig')

def render():
    result=json.loads((HERE/'results.json').read_bytes());counts=json.loads((HERE/'cells.json').read_bytes())
    rows=result['rows'];cs=result['contrasts']
    lookup={(r['group'],r['measure'],r['cohort']):r for r in rows}
    at=lambda g,m,c:lookup[g,m,c]['estimate']
    contrast=lambda g,m:next(r for r in cs if (r['group'],r['measure'])==(g,m))
    lf,lr=at('Latino_employed_2020','pid','full'),at('Latino_employed_2020','pid','retained')
    af,ar=at('all','pid','full'),at('all','pid','retained')
    rf,rr=at('R_renter_2020','pid','full'),at('R_renter_2020','pid','retained')
    lines=['# 2024年留存是否改变了已知的2020—2022年政治变化？','',
    '2026年9月8日 · LH-262 · 只分析2020—2022年已观测结果','',
    '答案是：在这份已发布队列中，限制为后来留存者会改变部分早期统计，个别净变化的正负号也会不同。变化大小取决于结局、固定群体和权重口径。这是队列选择的描述性诊断，没有识别留存的因果效应，也没有估计2022—2024年缺失结果的方向。', '',
    f"主分析的全体队列中，未加权众院变化差为{fmt(contrast('all','house')['unweighted_B_pp'])}个百分点，党派认同变化差为{fmt(contrast('all','pid')['unweighted_B_pp'])}个百分点；全体党派认同使用固定2022权重时，净变化从{fmt(af['weighted_delta_pp'])}变为{fmt(ar['weighted_delta_pp'])}个百分点。正负号不同的两个值都接近零，不宜仅凭方向写成较大的政治变化。",'',
    f"限定子组中，2020年拉美裔在业者的共和党倾向份额，未加权变化从完整两波的{fmt(lf['unweighted_delta_pp'])}变为后来留存者的{fmt(lr['unweighted_delta_pp'])}个百分点；差为{fmt(contrast('Latino_employed_2020','pid')['unweighted_B_pp'])}个百分点。同一子组加权后两者仍为正，差为{fmt(contrast('Latino_employed_2020','pid')['weighted_B_pp'])}个百分点。2020年共和党倾向租房者的党派认同加权变化，则从{fmt(rf['weighted_delta_pp'])}变为{fmt(rr['weighted_delta_pp'])}个百分点，差为{fmt(contrast('R_renter_2020','pid')['weighted_B_pp'])}个百分点。以上均为调查记录的匿名统计，不是群体总体效应。",'',
    '以上数字来自[完整计算结果](results.json)和[匿名转移格表](cells.json)，均经两波原件的独立逐行复算。', '',
    '## 人群、时序与口径','',
    '目标是已发布2020—2022两波文件中的11,009人，S=1表示后来出现在2020—2024三波发布文件，S=0表示没有出现。完整两波、后来留存、后来未留存分别为11,009、6,175、4,834人；两个固定子组分别为584／282／302人和749／401／348人。这里不是邀请响应率，也不是投票率。六人来源差异继续保留为未知，不阻止分析实际发布队列。', '',
    '所有群体固定于2020年：拉美裔定义为race=3或hispanic=1，且employ=1或2；共和党倾向租房者为pid7=5、6、7且ownhome=2。不按2022或2024身份重新筛人，不将2020在业者等同于工人阶级或2024所有拉美裔选民。', '',
    '**本轮是在已经查看2024结果之后指定的新诊断，不是结果盲态预注册。** [分析计划](analysis-plan.json)在首次计算本轮转移结果之前封存；[封印](analysis-plan-seal.json)保存时间与哈希。只选众院票和党派认同，不加入政策题；2022没有总统选举，没有构造2020—2022总统票比较。', '',
    '众院主统计限两年都参加选后问卷、两端都报告民主党或共和党候选人票的同人配对。CC20_412／CC22_412的候选槽位逐行查党派，不把“候选人1”一律当作某党。其他票、明确未投本场或未投票不属于此估计目标；未参加问卷、题目缺失、不确定与候选党派缺失继续保留为未知。', '',
    '党派认同取pid7_20／pid7_22：1—3为民主党倾向D，4为独立I，5—7为共和党倾向R，8及缺失为unknown。主分母要求两端为D／I／R，保留独立者。净变化统一为2022年的R份额减2020年R份额；I→R和R→I也计入。因此党派认同的“转入R／转出R”不等于单纯D↔R。没有把1—7数字当作等距得分。', '',
    '变量映射沿用[已核验的官方代码本映射摘录](variable-map.json)：党派认同第22—23页，众院题第130—131页，并以年度代码本核对实际数值编码。题目展示顺序不等于编码顺序。所选候选槽位的选前、选后党派在两者均非缺失时，2020及2022各有0个不一致；分别有1、5条所选槽位党派缺失，按unknown_party处理。', '',
    '## 同一套规则下的三个样本','',
    '表中“原队列n”尚未排除结局不适用或未知；“有效n”是本行净变化的实际分母。转入／转出是原始人数；众院对应D→R／R→D，党派认同对应D或I→R／R→D或I。百分点保留三位，仅为读数，完整精度在JSON和CSV中。', '',
    '| 固定群体 | 结局 | 人群 | 原队列n | 有效n | 转入R | 转出R | 未加权净变化（百分点） |',
    '|---|---|---|---:|---:|---:|---:|---:|']
    comparison=[];denominators=[]
    for r in rows:
        e=r['estimate'];f=r['flow'];prefix={'group':r['group'],'measure':r['measure'],'cohort':r['cohort']}
        lines.append(f"| {G[r['group']]} | {M[r['measure']]} | {C[r['cohort']]} | {f['target_n']} | {e['n']} | {e['forward_n']} | {e['reverse_n']} | {fmt(e['unweighted_delta_pp'])} |")
        directions={a+'_'+b+'_n':next((t['n'] for t in r['transitions'] if (t['before'],t['after'])==(a,b)),0) for a,b in [('D','R'),('R','D'),('D','I'),('I','D'),('I','R'),('R','I')]}
        comparison.append(dict(**prefix,**f,**{k:v for k,v in e.items() if k not in f},**directions,weight_column=r['weight_column']))
        denominators.append(dict(**prefix,**f))
    lines += ['', '可筛选的[完整比较表](comparison.csv)同时保留分母、方向人数、权重和、有效样本量及所有净变化；[全部状态转移表](transitions.csv)包括未知与不适用状态。', '',
    '党派认同的六个方向展开如下，另有D→D、I→I、R→R留在完整表中：','',
    '| 固定群体 | 人群 | D→R | R→D | D→I | I→D | I→R | R→I |','|---|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        if r['measure']!='pid':continue
        d={(x['before'],x['after']):x['n'] for x in r['transitions']}
        lines.append('| '+G[r['group']]+' | '+C[r['cohort']]+' | '+' | '.join(str(d[a,b]) for a,b in [('D','R'),('R','D'),('D','I'),('I','D'),('I','R'),('R','I')])+' |')
    lines += ['', '## 权重比较单列','',
    '未加权表描述实际发布队列。加权表把两波文件内已有的2022权重固定：众院票用commonpostweight_22，党派认同用commonweight_22。同一结局的三个样本使用相同列和正权重规则，分别除以自己的权重和；不使用2024权重，不拟合留存概率，也不乘第二层校正或裁剪权重。', '',
    '采用成人commonweight、选后题使用post权重的原则有[CES官方权重说明](https://tischcollege.tufts.edu/research-faculty/research-centers/cooperative-election-study/cooperative-election-study-faqs)支持。此处的目标是**同一份两波权重所定义的描述性基准**；专属两波权重的完整拟合细节未在本轮取得，不能据此声称任何子组已代表美国人口，或留存后的加权结果恢复了完整样本。来源及这一限制见[source-manifest.json](source-manifest.json)。', '',
    '实际所有结局有效配对都有正的相应2022权重，因此本轮每行未加权和加权的最终人数相同。权重仍明显降低有效样本量；n_eff=(Σw)²/Σw²只描述权重集中度，不是对选择误差的修正，也不是独立调查设计的置信保证。', '',
    '| 固定群体 | 结局 | 人群 | 正权重有效n | 权重和 | n_eff | 加权净变化（百分点） |',
    '|---|---|---|---:|---:|---:|---:|']
    for r in rows:
        e=r['estimate'];lines.append(f"| {G[r['group']]} | {M[r['measure']]} | {C[r['cohort']]} | {e['positive_n']} | {e['w']:.3f} | {e['n_eff']:.2f} | {fmt(e['weighted_delta_pp'])} |")
    lines += ['', '## 留存减完整两波的差值','',
    'B=Δ（后来留存）−Δ（完整两波）。各行的Δ始终使用同一结局定义、资格和权重。计划在本轮计算前选定绝对差2个百分点作为描述性参照，不是显著性门槛、科学通用标准或事后裁定；即使低于2点，接近零的净变化仍可能换号。', '',
    '| 固定群体 | 结局 | 未加权B（百分点） | 固定2022权重B（百分点） |','|---|---|---:|---:|']
    for c in cs:lines.append(f"| {G[c['group']]} | {M[c['measure']]} | {fmt(c['unweighted_B_pp'])} | {fmt(c['weighted_B_pp'])} |")
    lines += ['', '六项未加权差值均小于2个百分点；加权比较中，固定2020共和党倾向租房者的党派认同差值为+2.073个百分点。该群体在基线按R认同定义，基线R份额必然为100%，因此认同变化只可能持平或下降；这不能与其他群体的双向变化直接作机制比较。', '',
    '本诊断没有对已知完整样本结果进行校准再把恢复称为验证。完整两波净变化等于留存与未留存净变化按各自**有效配对人数**加权的平均；使用调查权重时，混合比例改为各自有效配对的**权重和**。它不是按6,175／11,009直接混合每项政治统计。上述恒等关系均经实际测试。', '',
    '## 资格、未知和缺权重分别记账','',
    '互斥分母恒等式是：原队列n=有效配对n+已知不属于目标n+资格仍未知n。“已知不属于目标”只要任一端明确为其他票、未投本场或未投票就成立；另一端即使未知，也不可能成为两端D/R配对。这类混合状态因此计入已知不适用。另有“任一端未知”一列，允许与已知不适用重叠；不能把它再加进互斥恒等式。党派认同的独立者属于有效配对，不属于排除。', '',
    '| 固定群体 | 结局 | 人群 | 原队列n | 有效配对n | 已知不适用n | 资格未知n | 任一端未知n |',
    '|---|---|---|---:|---:|---:|---:|---:|']
    for r in rows:
        f=r['flow'];lines.append(f"| {G[r['group']]} | {M[r['measure']]} | {C[r['cohort']]} | {f['target_n']} | {f['eligible_n']} | {f['known_ineligible_n']} | {f['unresolved_eligibility_n']} | {f['any_unknown_item_n']} |")
    lines += ['', '完整选取路径还列出：原队列→适用正权重子集→两端题目有明确状态子集→最终有效配对；众院另列两年选后问卷均参加人数。[分母明细](denominators.csv)保留全部18行；最终有效配对中缺权重和零权重人数均为0。完整状态表不把unknown_party、不确定或未答问卷改写成未投票。', '',
    '## 可以和不可以据此说明什么','',
    '已知早期结果表明，发布文件的后续选择会改变部分正在解释的政治统计，仅有基线党派留存率接近并不足以说明变化估计不受选择影响。与此同时，全体未加权两个结局的留存差值都较小。这里的证据是结局、群体及权重口径相关的，不能用一个总体留存率概括所有结果。', '',
    '部分子组的转换记录很少：固定2020拉美裔在业者的后来留存众院配对仅196人，D→R为1人、R→D为3人，n_eff为41.60。精确的小数位不表示精确的人口结论。本次不提供正态置信区间或显著性判断，也不把没有变化时的经验零方差当成无不确定性。旧2024区间代码保持原状，其边界修复仍属另一个任务。', '',
    '本次比较只覆盖2020—2022已有可用结局的人；早期题目本身的未知仍未被补全。它不能识别谁受邀、谁拒访、谁因质量检查被剔除；不能说明住房造成流失，不能推出2022—2024未知结果的偏差方向，也不能证明早期差小就意味着后期流失无害。固定2020队列还排除了2020以后成年的人。', '',
    '## 来源与复核','',
    '两波源：[Harvard Dataverse，2020—2022 CES Panel，V1.0](https://dataverse.harvard.edu/file.xhtml?fileId=10231930&version=1.0)；三波成员源：[2020—2024 CES Panel，V2.0](https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/CETPVT)。本轮沿用已核验本地原件，先核对固定SHA-256；网页重新访问遇到访问限制，没有据此虚构重新下载。', '',
    '6,175个三波成员全部连接到两波文件；两端ID均唯一且非缺失，七个2020核验字段及2022连接键均0差异。三波只读取成员键及既定2020核验字段，全部本轮政治结局和权重均来自两波文件。详细证据在[cells.json的link_audit](cells.json)中。', '',
    'OpenCode Go的Meta Muse 1.3实际生成匿名格表汇总函数；Codex核对公式、补充权重矩一致性校验、编写本地解析及测试，并另写不导入正式分析代码的原件复算。实际调用、完整输入消息和用量证据保存在run279；没有把受访者资料或实际统计发送给分包模型。', '',
    '按[README](README.md)可仅用Python标准库从匿名格表复算；这验证汇总计算，不能替代原始微数据复核。原件复算和监督者逐行独立计数均已另行执行。本轮没有Git操作、公开部署或GitHub Actions运行；不把本地通过写成外部CI通过。', '']
    # 众院有额外分母列，统一列集合，使CSV可直接读入。
    all_fields=list(dict.fromkeys(k for r in comparison for k in r))
    comparison=[{k:r.get(k,'') for k in all_fields} for r in comparison]
    all_d=list(dict.fromkeys(k for r in denominators for k in r))
    denominators=[{k:r.get(k,'') for k in all_d} for r in denominators]
    return {'report.md':'\n'.join(lines).encode('utf-8'),'comparison.csv':csv_bytes(comparison),
            'denominators.csv':csv_bytes(denominators),'transitions.csv':csv_bytes(counts['cells'])}

def main():
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');a=p.parse_args()
    for name,data in render().items():
        path=HERE/name
        if a.check:
            if path.read_bytes()!=data: raise ValueError('报告或表格字节不一致：'+name)
        else: path.write_bytes(data)
    print(json.dumps({'report':'report.md','comparison_rows':18,'check':a.check},ensure_ascii=False))

if __name__=='__main__':main()
